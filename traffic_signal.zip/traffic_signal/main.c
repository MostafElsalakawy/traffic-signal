
int main(void)
{
	app_start();
}


