﻿/*
 * button1.h
 *
 * Created: 05/09/2022 01:16:22 ص
 *  Author: Fannan
 */ 


#ifndef BUTTON_H_
#define BUTTON_H_
#include "../../MCAL/DIO/DIO.h"
void bottun_init(unit8_t buttonPort,unit8_t buttonPin);







#endif /* BUTTON1_H_ */