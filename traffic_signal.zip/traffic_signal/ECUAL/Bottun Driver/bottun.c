﻿/*
 * CFile1.c
 *
 * Created: 05/09/2022 01:15:50 ص
 *  Author: 
 */
#include "button.h" 
void bottun_init(unit8_t buttonPort,unit8_t buttonPin)
{
	DIO_init(buttonPort,buttonPin,IN);
}

