﻿/*
 * LED.c
 *
 * Created: 04/09/2022 11:27:56 م
 *  Author: Fannan
 */ 
#include "LED.h"
void LED_init(unit8_t ledPortal,unit8_t ledPin)
{
	DIO_init(ledPortal,ledPin,OUT);
}
void LED_on(unit8_t ledPortal,unit8_t ledPin)
{
	DIO_write(ledPortal,ledPin,HIGH);
}
void LED_off(unit8_t ledPortal,unit8_t ledPin)
{
	DIO_write(ledPortal,ledPin,LOW);
}
void LED_toggel(unit8_t ledPortal,unit8_t ledPin)
{
	DIO_toggel(ledPortal,ledPin);
}
void delay()
{
	unsigned int overflowes=0;

	TCCR0 |=(1<<0);
	while(overflowes<19532)
	{
		while((TIFR &(1<<0)) == 0);
		TIFR |= (1<<0);
		
		overflowes++;
	}
	
	TCCR0=0x00;

}
