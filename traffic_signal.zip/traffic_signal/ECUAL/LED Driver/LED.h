﻿/*
 * LED.h
 *
 * Created: 04/09/2022 11:28:58 م
 *  Author: Fannan
 */ 


#ifndef LED_H_
#define LED_H_
#include "../../MCAL/DIO/DIO.h"
void LED_init(unit8_t ledPortal,unit8_t ledPin);
void LED_on(unit8_t ledPortal,unit8_t ledPin);
void LED_off(unit8_t ledPortal,unit8_t ledPin);
void LED_toggel(unit8_t ledPortal,unit8_t ledPin);

void delay(void);

#endif /* LED_H_ */