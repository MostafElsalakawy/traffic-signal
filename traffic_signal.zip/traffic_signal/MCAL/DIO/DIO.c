﻿/*
 * DIO.c
 *
 * Created: 04/09/2022 04:36:46 م
 *  Author:
 */ 
#include "DIO.h"
void DIO_init(unit8_t portNumber,unit8_t pinNumber,unit8_t direction)
{
	switch(portNumber)
	{
	   case PORT_A:
		     if(direction==IN)
		     {
		     DDRA &=~(1<<pinNumber);	
		     }
			 else if (direction==OUT)
			 {
				 DDRA |= (1<<pinNumber);
			 }
			 else
			 {
				 LED_on(PORT_D,PIN0);
			 }
	   break;
	   case PORT_B:
	         if(direction==IN)
	         {
		        DDRB &=~(1<<pinNumber);
	         }
	        else if(direction==OUT)
	        {
		       DDRB |= (1<<pinNumber);
	        }
	       else
	       {
		    LED_on(PORT_D,PIN0);
	       }
	   break;
	      case PORT_C:
	           if (direction==IN)
	           {
		          DDRC &=~(1<<pinNumber);
	           }
	     if(direction==OUT)
	     {
		    DDRC |= (1<<pinNumber);
	     }
		 else
		 {
			 LED_on(PORT_D,PIN0);
		 }
	     break;
	   case PORT_D:
	        if(direction==IN)
	        {
		      DDRD &=~(1<<pinNumber);
	        }
	        else if(direction==OUT)
	        {
		      DDRD |= (1<<pinNumber);
	       }
		   else
		   {
			   LED_on(PORT_D,PIN0);
		   }
	   break;
	}
}

void DIO_write(unit8_t portNumber,unit8_t pinNumber,unit8_t value)
{
switch(portNumber)
{
	case PORT_A:
	if(value==LOW)
	{
		PORTA &=~(1<<pinNumber);
	}
	else if (value==HIGH)
	{
		PORTA |= (1<<pinNumber);
	}
	else
	{
		LED_on(PORT_D,PIN0);
	}
	break;
	case PORT_B:
	if(value==LOW)
	{
		PORTB &=~(1<<pinNumber);
	}
	else if(value==HIGH)
	{
		PORTB |= (1<<pinNumber);
	}
	else
	{
		LED_on(PORT_D,PIN0);
	}
	break;
	case PORT_C:
	if (value==LOW)
	{
		PORTC &=~(1<<pinNumber);
	}
	if(value==HIGH)
	{
		PORTC |= (1<<pinNumber);
	}
	else
	{
		LED_on(PORT_D,PIN0);
	}
	break;
	case PORT_D:
	if(value==LOW)
	{
		PORTD &=~(1<<pinNumber);
	}
	else if(value==HIGH)
	{
		PORTD |= (1<<pinNumber);
	}
	else
	{
		LED_on(PORT_D,PIN0);
	}
	break;
}	
}

void DIO_toggel(unit8_t portNumber,unit8_t pinNumber)
{
	if (portNumber==PORT_A)
	{
		PORTA^=(1<<pinNumber);
	}
   if (portNumber==PORT_B)
  {
	PORTB^=(1<<pinNumber);
  }
if (portNumber==PORT_C)
{
	PORTC^=(1<<pinNumber);
}
if (portNumber==PORT_D)
{
	PORTD^=(1<<pinNumber);
}
}



unit8_t DIO_read(unit8_t portNumber,unit8_t pinNumber)
{
	if (portNumber==PORT_A)
	{
	      return (PINA&(1<<pinNumber));
	}
if (portNumber==PORT_B)
{
	 return (PINB&(1<<pinNumber));
}
if (portNumber==PORT_C)
{
	return (PINC&(1<<pinNumber));
}
if (portNumber==PORT_D)
{
	return (PIND&(1<<pinNumber));
}

}
