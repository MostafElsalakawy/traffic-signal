﻿/*
 * TEYPDEFS.h
 *
 * Created: 04/09/2022 04:07:52 م
 *  Author: Fannan
 */ 


#ifndef TEYPDEFS_H_
#define TEYPDEFS_H_
typedef unsigned char unit8_t;




#endif /* TEYPDEFS_H_ */