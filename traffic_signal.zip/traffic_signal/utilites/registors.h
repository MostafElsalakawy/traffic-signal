﻿/*
 * registors.h
 *
 * Created: 04/09/2022 03:45:28 م
 *  Author: Fannan
 */ 


#ifndef REGISTORS_H_
#define REGISTORS_H_
//DIO REGISRIES
/*#define PORTA *((volatile unit8_t*)0x3B) 
#define DDRA *((volatile unit8_t*)0x3A)
#define PINA *((volatile unit8_t*)0x39)
//DIO REGISRIES
#define PORTB *((volatile unit8_t*)0x38)
#define DDRB *((volatile unit8_t*)0x37)
#define PINB *((volatile unit8_t*)0x36)
//DIO REGISRIES
#define PORTC *((volatile unit8_t*)0x35)
#define DDRC *((volatile unit8_t*)0x34)
#define PINC *((volatile unit8_t*)0x33)
//DIO REGISRIES
#define PORTD *((volatile unit8_t*)0x32)
#define DDRD *((volatile unit8_t*)0x31)
#define PIND *((volatile unit8_t*)0x30)*/
//PINs
#define PIN0 0
#define PIN1 1
#define PIN2 2
#define PIN3 3
#define PIN4 4
#define PIN5 5
#define PIN6 6
#define PIN7 7
//timer
/*#define TCCR0 *((volatile unit8_t*)0x53)
#define TCNT0 *((volatile unit8_t*)0x52)
#define TIFR *((volatile unit8_t*)0x58)*/



#endif /* REGISTORS_H_ */