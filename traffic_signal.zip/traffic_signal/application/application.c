﻿/*
 * CFile1.c
 *
 * Created: 13/09/2022 01:37:50 م
 *  Author: Fannan
 */ 
#include "application.h"
void app_start(void)
{
	bottun_init(PORT_D,PIN2);
	LED_init(PORT_B,PIN0);
	LED_init(PORT_B,PIN1);
	LED_init(PORT_B,PIN2);
	LED_init(PORT_A,PIN0);
	LED_init(PORT_A,PIN1);
	LED_init(PORT_A,PIN2);
	TCCR0=0x00;
	TCNT0=0x00;

	sei();
	MCUCR |= (1<<ISC00) | (1<<ISC01);
	GICR |=(1<<INT0);
	while(1)
	{
		while (mode==normal)
		{
			ledflag=green;
			LED_on(PORT_B,PIN0);
			delay();
			LED_off(PORT_B,PIN0);
			ledflag=yellow;
			LED_on(PORT_B,PIN1);
			LED_on(PORT_A,PIN2);
			delay();
			LED_off(PORT_B,PIN1);
			LED_off(PORT_A,PIN2);
			ledflag=red;
			LED_on(PORT_B,PIN2);
			LED_on(PORT_A,PIN0);
			delay();
			LED_off(PORT_B,PIN2);
			LED_off(PORT_A,PIN0);
		}
		while(mode==passing)
		{
			switch(state)
			{
				case green:
				mode=normal;
				LED_on(PORT_A,PIN1);
				LED_on(PORT_B,PIN1);
				delay();
				LED_off(PORT_A,PIN1);
				LED_off(PORT_B,PIN1);
				LED_on(PORT_A,PIN0);
				LED_on(PORT_B,PIN2);
				delay();
				LED_off(PORT_A,PIN0);
				LED_off(PORT_B,PIN2);
				break;
				case yellow:
				mode=normal;
				LED_on(PORT_A,PIN1);
				LED_on(PORT_B,PIN1);
				delay();
				LED_off(PORT_A,PIN1);
				LED_off(PORT_B,PIN1);
				LED_on(PORT_A,PIN0);
				LED_on(PORT_B,PIN2);
				delay();
				LED_off(PORT_A,PIN0);
				LED_off(PORT_B,PIN2);
				break;
				case red:
				mode=normal;
				LED_on(PORT_B,PIN2);
				LED_on(PORT_A,PIN0);
				delay();
				LED_off(PORT_B,PIN2);
				LED_off(PORT_A,PIN0);
				break;
				default:
				//error
				break;
			}
		}
	}
}
ISR(INT0_vect)
{
	
	mode=passing;
	state =ledflag;
	/*{
		num++;
	}
	else
	{
		num=0;*/

}