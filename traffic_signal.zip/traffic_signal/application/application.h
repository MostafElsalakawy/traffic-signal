﻿/*
 * application.h
 *
 * Created: 13/09/2022 01:38:29 م
 *  Author: Fannan
 */ 


#ifndef APPLICATION_H_
#define APPLICATION_H_
#include <avr/interrupt.h>
#include "../ECUAL/LED Driver/LED.h"
#include "../ECUAL/Bottun Driver/button.h"
#define normal 0
#define passing 1
#define red 0
#define yellow 1
#define green 2
unit8_t mode=normal;
unit8_t ledflag;
unit8_t state;
void app_start(void);



#endif /* APPLICATION_H_ */